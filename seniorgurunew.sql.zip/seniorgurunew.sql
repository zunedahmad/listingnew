-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2023 at 12:51 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seniorgurunew`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'zuned', 'zuned@gmail.com', NULL, '$2y$12$cpOWxbCJgRgrf0Cr3jKlXO4i412./BG8GTrryg7WmXak6BFZuWE56', NULL, '2023-12-22 06:32:40', '2023-12-22 06:32:40');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cimage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cnameslug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cname`, `cimage`, `created_at`, `updated_at`, `cnameslug`) VALUES
(1, 'Housing', '1703065586.png', '2023-12-20 04:16:27', '2023-12-22 01:13:04', 'housing'),
(2, 'Home Health & Hospice', '1703065783.png', '2023-12-20 04:19:43', '2023-12-22 05:50:39', 'home-health-&-hospice'),
(3, 'Resources & Services', '1703065857.png', '2023-12-20 04:20:57', '2023-12-22 05:50:57', 'resources-&-services'),
(4, 'Others', '1703065918.png', '2023-12-20 04:21:58', '2023-12-22 01:13:29', 'others'),
(5, 'Senior Living', '1703065983.png', '2023-12-20 04:23:03', '2023-12-22 05:48:52', 'senior-living');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

CREATE TABLE `listings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `listname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listimage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listcategory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listcity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `liststate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listcountry` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listzip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listaddress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listdescription` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `listings`
--

INSERT INTO `listings` (`id`, `listname`, `listimage`, `listcategory`, `listcity`, `liststate`, `listcountry`, `listzip`, `listaddress`, `listdescription`, `created_at`, `updated_at`) VALUES
(1, 'Traditions At Englewood', '1703139893.jpg', 'home-health-&-hospice', 'Englewood', 'Colorado', 'USA', '80113', '3500 South Sherman Street - Englewood, Colorado 80113', 'We aren’t your average 55+ community. Traditions at Englewood is a one of a kind option for the active adult wanting to pursue their own passions. Our communities are specifically designed to foster resident driven engagement through an active social scene.', '2023-12-21 00:54:54', '2023-12-26 04:41:01'),
(2, 'Eiber Village At Garrison Station', '1703140004.jpg', 'housing', 'Lakewood', 'Colorado', 'USA', '80215', '1320 Everett Ct - Lakewood, Colorado 80215', 'Eiber Village is a senior affordable housing community for those earning 60% of the Area Median Income. Amenities include community spaces, lush community gardens, private patios, free WiFi, ample on-street parking, and much more!', '2023-12-21 00:56:44', '2023-12-26 04:48:32'),
(3, 'HumanGood', '1703140135.jpeg', 'senior-living', 'Pleasanton', 'California', 'USA', '94588', '6120 Stoneridge Mall Road Suite 100, Pleasanton, CA 94588 - Pleasanton, California 94588', 'Our mission is to help older adults live their best lives possible, however they define it. The products and services we offer are designed to support those we serve, their families and our team members in the pursuit of an engaged, purposeful life. Why? Because everyone should have the opportunity to live life with enthusiasm, confidence and security, regardless of physical, social or economic circumstances.', '2023-12-21 00:58:55', '2023-12-26 04:48:59'),
(4, 'Procare Home Care Agency', '1703140269.jpeg', 'others', 'Plano', 'Texas', 'USA', '75024', '7924 Preston Rd Ste 100a - Plano, Texas 75024', 'The Forum at Park Lane is an elegant full-service senior living community that provides independent living apartments and assisted living suites. We have a Healthcare Center for skilled nursing and rehabilitation, and guest or respite/short stays to experience The Forum firsthand or while the family is away. We are located on seven beautifully landscaped acres across Park Lane from North Park Mall, on a quiet street lined with stately oak trees.', '2023-12-21 01:01:09', '2023-12-26 04:49:13'),
(5, 'The Forum At Park Lane', '1703140368.jpg', 'home-health-&-hospice', 'Dallas', 'Georgia', 'USA', '75225', '7827 Park Ln - Dallas, Georgia 75225', 'The Forum at Park Lane is an elegant full-service senior living community that provides independent living apartments and assisted living suites. We have a Healthcare Center for skilled nursing and rehabilitation, and guest or respite/short stays to experience The Forum firsthand or while the family is away. We are located on seven beautifully landscaped acres across Park Lane from North Park Mall, on a quiet street lined with stately oak trees.', '2023-12-21 01:02:48', '2023-12-26 04:49:26'),
(8, 'Stonemere Rehabilitation Center', '1703139424.jpg', 'resources-&-services', 'Frisco', 'Texas', 'usa', '75035', '11855 Lebanon Rd - Frisco, Texas 75035', 'Our Accelerated Recovery program specializes in providing the latest in technology, equipment, and techniques for those requiring short-term rehabilitation after a recent hospitalization. Offering physical, occupational, and speech therapy, our rehabilitation team collaborates with physicians to develop a unique care plan with your individual needs taken into account. We understand that there is no “one size fits all” approach to restoring one’s health. We offer 24-hour nursing care for medically complex patients to include those needing IV antibiotic therapy, wound care, stroke and orthopedic rehabilitation, and more', '2023-12-21 00:47:04', '2023-12-26 04:50:03'),
(9, 'Frances\' Family Home Health Care', '1703139563.jpg', 'home-health-&-hospice', 'Dallas', 'Georgia', 'usa', '75232', '5787 S Hampton Rd Ste - Dallas, Georgia 75232', 'Property Ratings at Frances\' Family Home Health Care', '2023-12-21 00:49:23', '2023-12-26 04:49:42'),
(10, 'Heritage At Church Ranch 55 Plus Apartments', '1703139686.jpg', 'housing', 'Westminster', 'Colorado', 'USA', '80021', '10050 Wadsworth Blvd - Westminster, Colorado 80021', 'Deeply Affordable Apartments At Over $600 Less Than Nearby Communities! HURRY – our new rent-restricted apartments are going fast! Submit your application paperwork quickly and easily today to reserve your brand-new home. Opening in Spring 2022, you\'re invited to apply at Heritage at Church Ranch 55 plus apartments today! To begin the reservation process, visit our floor plans page and select either the one or two-bedroom floor plan and complete a preliminary application. Within 1-2 weeks we\'ll contact you to schedule an in-person tax credit application. Upon completing the tax credit application, and paying a $300 deposit, you\'ll learn the rent level for which your household qualifies, and will then be able to select your floor plan. One-bedroom rents will range from $1,179 - $1,695 per month, and two-bedroom rents will range from $1,416 - $2,033 per month. These are estimated rents and are subject to change based on the 2022 tax credit program guidelines. Nestled among greenery and located near the historic downtown of Westminister, CO, the Heritage at Church Ranch 55+ apartments offer convenient access to both Denver and Boulder. With a professional management and maintenance team supporting the community, you\'ll have ample time to enjoy all of its extraordinary amenities. You\'ll enjoy the hiking and biking trails of the Dry Creek Trail System as well as nearby local shops and services. The community features a beautifully restored barn where you\'ll be able to reserve meeting space for group activities. Your open and spacious 1 or 2 bedroom apartment home will feature gorgeous cabinetry, luxury wood-plank vinyl flooring, Energy-Star kitchen appliances, walk-in closets, and designer lighting. NOTE: The on-site leasing office is open BY APPOINTMENT ONLY. Please call for more details & to schedule a time to meet with one of our leasing professionals today. *Heritage at Church Ranch participates in an affordable housing program. Household income & student status limitations apply. Please call for more details', '2023-12-21 00:51:26', '2023-12-26 04:50:17'),
(11, 'Morningside Retirement', '1703139795.jpg', 'housing', 'Wheat Ridge', 'Colorado', 'USA', '80033', '3650 Vance St, Wheat Ridge - Wheat Ridge, Colorado 80033', 'Morningside Retirement offers a mixture of comfort, quality, and design. This property is situated at 3650 Vance St in Wheat Ridge. The leasing staff will assist you in finding the perfect apartment. Contact us today to see available floor plans and make your move to Morningside Retirement.', '2023-12-21 00:53:15', '2023-12-26 04:50:23'),
(12, 'CC Young Assisted Living', '1703140581.jpg', 'home-health-&-hospice', 'Lawther', 'Andaman and Nicobar IslandS', 'INDIA', '75214', '4847 W Lawther - Bombuflat, Andaman and Nicobar Islands 75214', 'The Assisted Living team at CC Young is committed to creating the optimal balance between your individual needs and the way you want to live. This dedication reflects our founder’s mission to provide support and care for seniors with an unwavering compassionate spirit. The CC Young Life Enrichment team offers residents a full calendar of activities and outings that engage the mind and encourage socialization. Choose from two distinctive residences and floorplans in The Hillside and The Vista to flourish in body, mind and spirit.', '2023-12-21 01:06:21', '2023-12-26 04:50:36'),
(13, 'Highland Springs', '1703140756.jpg', 'resources-&-services', 'Dallas', 'Georgia', 'USA', '75252', '7910 Frankford Rd - Dallas, Georgia 75252', 'Assisted Living\r\nCompassionate assisted living in Dallas, TX\r\nToday, there are more choices than ever when it comes to assisted living in the Dallas, TX area. One of the best options is the Highland Springs continuing care neighborhood, which provides residents with an unparalleled level of care and support in a stimulating environment.\r\nThe assisted living program is custom-made for people who are generally healthy, but who require help with day-to-day activities like medication and meal preparation.\r\nBest of all, our assisted living residents can access the wide range of amenities on the 89-acre Highland Springs campus, including the fitness center and restaurants.', '2023-12-21 01:09:16', '2023-12-26 04:50:43'),
(19, 'test', '1703587230.jpg', 'senior-living', 'Jaipur', 'Rajasthan', 'India', '322001', 'itcompanysunjay lorem Ipsum content itcompanysunjay lorem Ipsum content itcompanysunjay lorem Ipsum content', 'itcompanysunjay lorem Ipsum content itcompanysunjay lorem Ipsum content itcompanysunjay lorem Ipsum content', '2023-12-26 05:10:31', '2023-12-26 05:10:31');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_12_20_082229_create_category_table', 1),
(6, '2023_12_20_111929_create_listings_table', 2),
(7, '2023_12_22_062421_add_column_to_category_table', 3),
(8, '2023_12_22_115721_create_admins_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
